function [h] = h(x,theta)
h = sigmoid(x * theta);
end


