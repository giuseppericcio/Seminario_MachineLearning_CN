function val = h(x,theta)
val = x * theta;
end

